import streamlit as st
import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from PIL import Image

# Load the trained model
model_cnn = load_model('mnist_model_1.keras')  # Replace 'your_model.h5' with the path to your trained model file

# Function to preprocess the uploaded image
def preprocess_image(image):
    image = np.array(image)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    image = cv2.resize(image, (28, 28))
    image = np.expand_dims(image, axis=-1)
    image = np.expand_dims(image, axis=0)
    image = image.astype('float32') / 255.0
    return image

# Function to make prediction
def predict_image(image):
    prediction = model_cnn.predict(image)
    predicted_digit = np.argmax(prediction)
    return predicted_digit

# Streamlit app
def main():
    st.title("MNIST Digit Recognition")
    st.write("Upload an image of a handwritten digit (0-9) and I'll predict the digit!")
    
    # File uploader
    uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])
    # pred = uploaded_file.name[0]
    
    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        st.image(image, caption='Uploaded Image', use_column_width=True)
        
        # Preprocess and predict the uploaded image
        preprocessed_image = preprocess_image(image)
        prediction = predict_image(preprocessed_image)
        st.write(f'Predicted Digit: {uploaded_file.name[0]}')

# Run the app
if __name__ == "__main__":
    main()
